CREATE TABLE IF NOT EXISTS fact_usage (
    customer_id INT,
    total_minutes INT,
    total_gb FLOAT,
    usage_date DATE
);